# ADL v0.2.0-beta — spec bundle

This bundle mirrors the repository layout of ReddiAgent Lab
(github.com/reddinft/reddiagent-lab) so every tool runs as-is.

## Contents

- `specs/ADL-v0.2.md` — the canonical Agent Definition Language specification
- `specs/ADL-v0.2.schema.json` — machine-checked JSON Schema
- `docs/ADL-v0.1-to-v0.2-MIGRATION.md` — migration guide from v0.1
- `examples/v0.2/` — 16 validated example agent definitions
- `scripts/adl_v02_conformance.py` — 5-level conformance checker
- `scripts/rap_receipt_validator.py` — receipt-integrity validator (10 evidence
  layers; settlement proof alone can never produce accept)
- `scripts/rap_receipt_integrity_benchmark.py` — the 14-case threat model the
  validator is tested against

## Prerequisites

Python 3.12+ with two packages:

    pip install pyyaml jsonschema

## Try it

    python3 scripts/adl_v02_conformance.py examples/v0.2/simple-agent.yaml
    python3 scripts/adl_v02_conformance.py examples/v0.2/payment-agent.yaml
    python3 scripts/rap_receipt_integrity_benchmark.py

Licensing: code Apache-2.0 (`LICENSE`), specifications and docs CC BY 4.0
(`LICENSE-SPECS.md`). Feedback: see `CONTRIBUTING.md`.
